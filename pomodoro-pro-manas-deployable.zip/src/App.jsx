
import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogTrigger, DialogContent, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { PieChart, Pie, Cell, Tooltip, ResponsiveContainer, BarChart, Bar } from "recharts";

const defaultTime = 60 * 60;
const alarmSound = new Audio("/alarm.mp3");

export default function PomodoroPro() {
  const [time, setTime] = useState(defaultTime);
  const [running, setRunning] = useState(false);
  const [customMinutes, setCustomMinutes] = useState(60);
  const [sessions, setSessions] = useState(0);
  const [breaks, setBreaks] = useState(0);
  const [pausedCount, setPausedCount] = useState(0);
  const [visits, setVisits] = useState(0);
  const [weeklyData, setWeeklyData] = useState([]);

  useEffect(() => {
    fetchVisitCount();
    fetchWeeklyStats();
  }, []);

  const fetchVisitCount = () => {
    const count = Number(localStorage.getItem("visitCount") || 0) + 1;
    localStorage.setItem("visitCount", count.toString());
    setVisits(count);
  };

  const fetchWeeklyStats = () => {
    const storedData = JSON.parse(localStorage.getItem("weeklyStats") || "[]");
    const today = new Date().toLocaleDateString('en-US', { weekday: 'short' });
    const updated = storedData.map((d) =>
      d.day === today ? { ...d, sessions: d.sessions + 1 } : d
    );
    const newData = updated.length ? updated : ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"].map(day => ({ day, sessions: 0 }));
    localStorage.setItem("weeklyStats", JSON.stringify(newData));
    setWeeklyData(newData);
  };

  useEffect(() => {
    let timer;
    if (running && time > 0) {
      timer = setInterval(() => setTime((prev) => prev - 1), 1000);
    } else if (time === 0 && running) {
      setRunning(false);
      setSessions((prev) => prev + 1);
      alarmSound.play();
      fetchWeeklyStats();
    }
    return () => clearInterval(timer);
  }, [running, time]);

  const formatTime = (seconds) => {
    const m = String(Math.floor(seconds / 60)).padStart(2, '0');
    const s = String(seconds % 60).padStart(2, '0');
    return `${m}:${s}`;
  };

  const handlePause = () => {
    setRunning(false);
    setPausedCount((prev) => prev + 1);
  };

  const handleBreak = () => {
    setBreaks((prev) => prev + 1);
    setTime(5 * 60);
    setRunning(false);
  };

  const handleSetTimer = () => {
    setTime(customMinutes * 60);
    setRunning(false);
  };

  const pieData = [
    { name: "Sessions", value: sessions },
    { name: "Breaks", value: breaks },
    { name: "Paused", value: pausedCount },
  ];

  const COLORS = ["#00C49F", "#FFBB28", "#0088FE"];

  return (
    <div className="min-h-screen bg-neutral-900 text-white flex flex-col items-center">
      <div className="w-full text-right p-4">
        <Dialog>
          <DialogTrigger>
            <Button variant="ghost">Settings</Button>
          </DialogTrigger>
          <DialogContent className="bg-neutral-800 text-white transition-all duration-300">
            <DialogTitle className="text-xl font-bold">Session Settings</DialogTitle>
            <div className="space-y-4 mt-2">
              <Input
                type="number"
                min="1"
                value={customMinutes}
                onChange={(e) => setCustomMinutes(e.target.value)}
                className="text-black"
              />
              <Button onClick={handleSetTimer}>Set Custom Timer</Button>
              <div className="text-sm">Sessions Completed: {sessions}</div>
              <div className="text-sm">Breaks Taken: {breaks}</div>
              <div className="text-sm">Paused Count: {pausedCount}</div>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      <main className="flex-grow flex flex-col items-center justify-center mt-10">
        <div className="w-72 h-72 border-4 border-neutral-700 rounded-full flex items-center justify-center">
          <span className="text-7xl font-mono drop-shadow-lg">{formatTime(time)}</span>
        </div>

        <div className="flex flex-col gap-4 mt-8">
          <Button className="w-40 bg-white text-black hover:bg-gray-200" onClick={() => setRunning(true)}>Start</Button>
          <Button className="w-40 bg-white text-black hover:bg-gray-200" onClick={handlePause}>Pause</Button>
          <Button className="w-40 bg-white text-black hover:bg-gray-200" onClick={() => { setTime(defaultTime); setRunning(false); }}>Reset</Button>
          <Button className="w-40 bg-white text-black hover:bg-gray-200" onClick={handleBreak}>Break</Button>
        </div>
      </main>

      <div className="h-48"></div>

      <section className="w-full max-w-5xl mt-10 grid grid-cols-1 md:grid-cols-2 gap-8 px-4">
        <div className="bg-neutral-800 p-4 rounded-2xl">
          <h3 className="text-xl font-bold mb-4">Usage Breakdown</h3>
          <ResponsiveContainer width="100%" height={200}>
            <PieChart>
              <Pie data={pieData} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={70}>
                {pieData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
              </Pie>
              <Tooltip />
            </PieChart>
          </ResponsiveContainer>
        </div>

        <div className="bg-neutral-800 p-4 rounded-2xl">
          <h3 className="text-xl font-bold mb-4">Weekly Progress</h3>
          <ResponsiveContainer width="100%" height={200}>
            <BarChart data={weeklyData}>
              <Bar dataKey="sessions" fill="#00C49F" radius={[6, 6, 0, 0]} />
              <Tooltip />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </section>

      <footer className="w-full text-center mt-10 space-y-2 pb-10">
        <div className="text-sm">Total Visits: {visits}</div>
        <div className="bg-neutral-800 p-4 rounded-xl max-w-4xl mx-auto mt-2">Ad Space (Your Ad Here)</div>
        <div className="text-xs mt-2">© {new Date().getFullYear()} Manas Kumar. All rights reserved.</div>
      </footer>
    </div>
  );
}
